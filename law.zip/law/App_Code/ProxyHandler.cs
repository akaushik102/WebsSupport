using System;
using System.IO;
using System.Net;
using System.Web;

public class ProxyHandler : IHttpHandler
{
    public void ProcessRequest(HttpContext context)
    {
        // Add CORS headers
        context.Response.AddHeader("Access-Control-Allow-Origin", "*");
        context.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        context.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        
        if (context.Request.HttpMethod == "OPTIONS")
        {
            context.Response.StatusCode = 200;
            context.Response.End();
            return;
        }
        
        string path = context.Request.QueryString["path"];
        
        if (string.IsNullOrEmpty(path))
        {
            context.Response.StatusCode = 400;
            context.Response.ContentType = "application/json";
            context.Response.Write("{\"error\": \"Path parameter is required\"}");
            return;
        }

        string targetUrl = "https://portal.amity.edu/NewOnlineForm/" + path;
        
        // Append original query string (excluding 'path' parameter)
        string originalQuery = "";
        foreach (string key in context.Request.QueryString.AllKeys)
        {
            if (key != "path" && key != null)
            {
                originalQuery += "&" + key + "=" + context.Request.QueryString[key];
            }
        }
        if (!string.IsNullOrEmpty(originalQuery))
        {
            targetUrl += "?" + originalQuery.TrimStart('&');
        }
        
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(targetUrl);
            request.Method = context.Request.HttpMethod;
            request.ContentType = context.Request.ContentType ?? "application/json";
            request.Timeout = 30000;
            
            // Copy POST/PUT body
            if ((context.Request.HttpMethod == "POST" || context.Request.HttpMethod == "PUT"))
            {
                if (context.Request.ContentLength > 0)
                {
                    using (Stream reqStream = request.GetRequestStream())
                    {
                        context.Request.InputStream.CopyTo(reqStream);
                    }
                }
            }
            
            // Get response
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                context.Response.StatusCode = (int)response.StatusCode;
                context.Response.ContentType = response.ContentType;
                
                using (Stream responseStream = response.GetResponseStream())
                {
                    responseStream.CopyTo(context.Response.OutputStream);
                }
            }
        }
        catch (WebException ex)
        {
            if (ex.Response != null)
            {
                HttpWebResponse errorResponse = (HttpWebResponse)ex.Response;
                context.Response.StatusCode = (int)errorResponse.StatusCode;
                
                using (Stream responseStream = errorResponse.GetResponseStream())
                using (StreamReader reader = new StreamReader(responseStream))
                {
                    context.Response.ContentType = "application/json";
                    context.Response.Write(reader.ReadToEnd());
                }
            }
            else
            {
                context.Response.StatusCode = 500;
                context.Response.ContentType = "application/json";
                context.Response.Write("{\"error\": \"" + ex.Message.Replace("\"", "\\\"") + "\"}");
            }
        }
        catch (Exception ex)
        {
            context.Response.StatusCode = 500;
            context.Response.ContentType = "application/json";
            context.Response.Write("{\"error\": \"" + ex.Message.Replace("\"", "\\\"") + "\"}");
        }
    }

    public bool IsReusable
    {
        get { return false; }
    }
}