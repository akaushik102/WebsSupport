import { IProgram } from '../app/service/landingservice.service';

export const filterDisiple = (data: IProgram[]) => {
  const result: { Discipline: string; DisciplinePopularity: string }[] = [];

  data.forEach((d) => {
    // Discipline
    if (d.Discipline && d.Discipline.trim() !== '') {
      result.push({
        Discipline: d.Discipline,
        DisciplinePopularity: d.DisciplinePopularity,
      });
    }

    // Discipline1
    if (d.Discipline1 && d.Discipline1.trim() !== '') {
      result.push({
        Discipline: d.Discipline1,
        DisciplinePopularity: d.DisciplinePopularity1,
      });
    }

    // Discipline3
    if (d.Discipline3 && d.Discipline3.trim() !== '') {
      result.push({
        Discipline: d.Discipline3,
        DisciplinePopularity: d.DisciplinePopularity3,
      });
    }
  });

  // Remove duplicates (like SQL DISTINCT)
  const distinctDisiplines = Array.from(new Map(result.map((item) => [item.Discipline, item]))).map((entry) => entry[1]);

  // Sort by popularity (ascending)

  const disiplines = distinctDisiplines
    .sort((a, b) => {
      return parseInt(a.DisciplinePopularity) - parseInt(b.DisciplinePopularity);
    })
    .map((d) => d.Discipline);
  return disiplines
};
