import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from '../environments/environment';

@Injectable({ providedIn: 'root' })
export class CryptoPayloadService {

  private readonly key = CryptoJS.enc.Utf8.parse(environment.payloadAesKey);
  private readonly iv  = CryptoJS.enc.Utf8.parse(environment.payloadAesIv);

  encrypt(payload: object): string {
    const withTs = { ...payload, ts: Date.now() };
    const json   = JSON.stringify(withTs);
    return CryptoJS.AES.encrypt(
      CryptoJS.enc.Utf8.parse(json),
      this.key,
      { iv: this.iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
    ).toString();
  }

  decrypt(cipherText: string): any {
    try {
      const bytes = CryptoJS.AES.decrypt(
        cipherText,
        this.key,
        { iv: this.iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
      );
      const json = bytes.toString(CryptoJS.enc.Utf8);
      return JSON.parse(json);
    } catch {
      return null;
    }
  }
}