import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, map, switchMap } from 'rxjs';
import { environment } from '../environments/environment';
import { CryptoPayloadService } from './crypto-payload.service';

export interface Program {
  Level?: string;
  Discipline?: string;
  Program?: string;
  Specialization?: string;
  CourseCode?: string;
  ProgramName?: string;
  CourseType?: string;
}

export interface Nationality {
  Nationality: string;
}

export interface FormData {
  FormNo?: number;
  fullName?: string;
  courseCode?: string;
  userGenNo?: string;
  password?: string;
  paid?: boolean;
  nationality?: string;
  programType?: string;
  courseCd?: string;
}

export interface OtpResponse {
  success?: boolean;
  message?: string;
  loginNo?: string;
  alreadyExists?: boolean;
  formNo?: string;
  token?: string;
  caseType?: string;
  form?: FormData[];
  programs?: Program[];
  nationalities?: Nationality[];
  INTNL?: boolean;
}

export interface FinalSubmitResponse {
  success: boolean;
  message: string;
  formNo?: number;
  userGenNo?: string;
  loginNo?: string;
  INTNL?: boolean;
  form?: {
    formNo: number;
    password: string;
    paid: boolean;
    fullName: string;
    nationality: string;
    programType: string;
    courseCd: string;
    userGenNo: string;
    specialization?: string;
    experience?: string;
  }[];
}

export interface TransactionSucessResponse {
  success: true;
  approved: boolean;
  token: string;
  data: {
    uid: string;
    campusId: string;
    campusName: string;
    courseCode: string;
    courseName: string;
    formNo: number;
    transactionNumber: string;
    pgResponseCode: string;
    pgResponse: string;
    paymentStatus: string;
    pageURL: string;
    studentName: string;
    studentEmail: string;
    studentMobile: string;
    studentCountry: string;
    studentCampus: string;
    studentLevel: string;
    studentDiscipline: string;
    studentCourse: string;
    studentProgram: string;
  };
}

export interface TransactionFailureResponse {
  success: false;
  message: string;
}

export type TransactionStatusResponse =
  | TransactionSucessResponse
  | TransactionFailureResponse;

export type TransactionData = TransactionSucessResponse['data'];

export interface IProgram {
  Level: string;
  Discipline: string;
  Discipline1: string;
  Discipline3: string;
  Program: string;
  Specialization: string;
  Programs: string;
  CourseCode: string;
  ProgramPopularity: string;
  DisciplinePopularity: string;
  DisciplinePopularity1: string;
  DisciplinePopularity3: string;
  CoursePopularity: string;
}

export interface CountryCodeResponse {
  success: boolean;
  message: string;
  data: { CountryCode: string }[];
}

export interface ProgramListResponse {
  success: boolean;
  message: string;
  data?: IProgram[];
}

const ACCESS_KEY = 'camadmsiteEsLrxhRxV8BkbYKMCH5BAw==';
const SECRET_KEY = 'camadmsiteIT1ty2E/ZP3D+nniosybWgty';

@Injectable({ providedIn: 'root' })
export class LandingserviceService {
  private baseUrl = environment.apiBase;

  // private sendOtpUrl = `${this.baseUrl}/OnlineForms/CampaignAdmissionEduSite`;
  // private verifyOtpUrl = `${this.baseUrl}/OnlineForms/CampaignAdmissionVerifyMobile`;
  // private createFormUrl = `${this.baseUrl}/OnlineForms/CampaignAdmissionCreateForm`;
  // private processPaymentUrl = `${this.baseUrl}/OnlineForms/ProcessPaymentOnline`;
  // private bindCountryCodeUrl = `${this.baseUrl}/OnlineForms/BindCountryCodes`;
  // private bindProgramListUrl = `${this.baseUrl}/OnlineForms/BindProgramList`;
  // private transactionStatusUrl = `${this.baseUrl}/OnlineForms/GetTransactionStatusByUID`;
  // private loginCheckUrl = `${this.baseUrl}/OnlineForms/FormCompltedeDirectLoginCheck`;

  private sendOtpUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/CampaignAdmissionEduSite`;
  private verifyOtpUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/CampaignAdmissionVerifyMobile`;
  private createFormUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/CampaignAdmissionCreateForm`;
  private processPaymentUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/ProcessPaymentOnline`;
  private bindCountryCodeUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/BindCountryCodes`;
  private bindProgramListUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/BindProgramList`;
  private transactionStatusUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/GetTransactionStatusByUID`;
  private loginCheckUrl = `${this.baseUrl}/NewOnlineForm/OnlineForms/FormCompltedeDirectLoginCheck`;

  private headers = new HttpHeaders({
    'Content-Type': 'application/x-www-form-urlencoded',
  });

  constructor(
    private http: HttpClient,
    private crypto: CryptoPayloadService,
  ) {}

  private encBody(payload: object): string {
    const encrypted = this.crypto.encrypt({
      accessKey: ACCESS_KEY,
      secretKey: SECRET_KEY,
      ...payload,
    });
    return 'data=' + encodeURIComponent(encrypted);
  }

  private dec<T>(): (source: Observable<{ d: string }>) => Observable<T> {
    return (source) =>
      source.pipe(
        map((res) => {
          if (res && res.d) {
            return this.crypto.decrypt(res.d) as T;
          }
          return res as unknown as T;
        }),
      );
  }

  getLastDateToApply() {
    const loginPayload = {
      Username: 'amity@!noida',
      Password: 'amity#@!noida',
    };

    return this.http
      .post<any>(
        'https://amity.edu/amitywebapi/api/Amityapi/login1',
        loginPayload,
      )
      .pipe(
        switchMap((auth) => {
          const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: `Bearer ${auth.AccessToken}`,
          });

          return this.http.get<any>(
            'https://amity.edu/amitywebapi/api/Amityapi/GetLastDatetoApply',
            { headers },
          );
        }),
      );
  }

  sendOtp(data: {
    firstName: string;
    email: string;
    countryCode: string;
    mobile: string;
    pageUrl?: string;
    campusId?: string;
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
    utm_content?: string;
    utm_term?: string;
    utm_location?: string;
    state?: string;
    city?: string;
    sourceReferral?: string;
    sGCLID?: string;
  }): Observable<OtpResponse> {
    return this.http
      .post<{
        d: string;
      }>(
        this.sendOtpUrl,
        this.encBody({ pageUrl: window.location.href, ...data }),
        { headers: this.headers },
      )
      .pipe(this.dec<OtpResponse>());
  }

  verifyOtp(
    loginNo: string,
    otp: string,
    campusId?: string,
  ): Observable<OtpResponse> {
    return this.http
      .post<{
        d: string;
      }>(
        this.verifyOtpUrl,
        this.encBody({ loginNo, otp, ...(campusId ? { campusId } : {}) }),
        { headers: this.headers },
      )
      .pipe(this.dec<OtpResponse>());
  }

  submitFinalForm(data: {
    firstName: string;
    email: string;
    countryCode: string;
    mobile: string;
    courseCode: string;
    formNo: string | number;
    loginNo: string;
    INTNL?: boolean;
    campusId?: string;
    specialization?: string;
    experience?: string;
  }): Observable<FinalSubmitResponse> {
    return this.http
      .post<{ d: string }>(
        this.createFormUrl,
        this.encBody({
          formType: data.INTNL ? 'OIN' : 'ON',
          aicCode: '',
          userIp: '',
          firstName: data.firstName,
          email: data.email,
          countryCode: data.countryCode,
          mobile: data.mobile,
          courseCode: data.courseCode,
          formNo: data.formNo?.toString() ?? '',
          ...(data.campusId ? { campusId: data.campusId } : {}),
          ...(data.specialization
            ? { specialization: data.specialization }
            : {}),
          ...(data.experience ? { experience: data.experience } : {}),
        }),
        { headers: this.headers },
      )
      .pipe(this.dec<FinalSubmitResponse>());
  }

  getCountryCodes(): Observable<CountryCodeResponse> {
    return this.http
      .post<{
        d: string;
      }>(this.bindCountryCodeUrl, this.encBody({}), { headers: this.headers })
      .pipe(this.dec<CountryCodeResponse>());
  }

  getProgramList(campusId?: string): Observable<ProgramListResponse> {
    return this.http
      .post<{
        d: string;
      }>(this.bindProgramListUrl, this.encBody(campusId ? { campusId } : {}), {
        headers: this.headers,
      })
      .pipe(this.dec<ProgramListResponse>());
  }

  processPayment(uid: string): Observable<any> {
    return this.http.post<any>(
      this.processPaymentUrl,
      new URLSearchParams({ UID: uid }).toString(),
      { headers: this.headers },
    );
  }

  verifyCompletedFormToken(token: string): Observable<any> {
    return this.http.post<any>(
      this.loginCheckUrl,
      new URLSearchParams({ token }).toString(),
      { headers: this.headers },
    );
  }

  getTransactionStatus(uid: string): Observable<TransactionStatusResponse> {
    return this.http.post<TransactionStatusResponse>(
      this.transactionStatusUrl,
      new URLSearchParams({
        accessKey: ACCESS_KEY,
        secretKey: SECRET_KEY,
        uid,
      }).toString(),
      { headers: this.headers },
    );
  }
}
