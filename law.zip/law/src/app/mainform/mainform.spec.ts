import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Mainform } from './mainform.component';

describe('Mainform', () => {
  let component: Mainform;
  let fixture: ComponentFixture<Mainform>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Mainform]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Mainform);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
