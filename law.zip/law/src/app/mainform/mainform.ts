import { Component, OnInit, OnDestroy } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormsModule,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IProgram, LandingserviceService, OtpResponse } from '../service/landingservice.service';
import { Router, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs';
import Swal from 'sweetalert2';
import { filterDisiple } from '../../helper';

import { ChangeDetectorRef } from '@angular/core';

declare const Moengage: any;

@Component({
  selector: 'app-mainform',
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './mainform.html',
  styleUrl: './mainform.css',
})
export class Mainform implements OnInit, OnDestroy {
  landingForm!: FormGroup;
  isSubmitting = false;
  isSubmitbutton = false;
  otpSent = false;
  otpVerified = false;
  otpMessage = '';
  otpStatus: 'success' | 'error' | '' = '';
  isEditMode = false;
  showPreview = false;

  loginNo = '';
  formNo = '';
  countryCodes: string[] = [];
  programList: IProgram[] = [];

  filteredDisciplines: string[] = [];
  filteredPrograms: string[] = [];
  filteredSpecializations: string[] = [];

  selectedLevel = '';
  selectedDiscipline = '';
  selectedProgram = '';
  selectedMode: 'national' | 'international' = 'national';

  otpTimer = 0;
  otpInterval: any = null;
  isNationalLocked = false;
  isInternationalLocked = false;
  previewData: any = null;
  utmParams: any = {};

  filteredLevels: string[] = [];

  lastDateText: string = '';

  private routerSubscription!: Subscription;

  constructor(
    private fb: FormBuilder,
    private landingService: LandingserviceService,
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.resetMoengageSession();

    this.getLastDate();

    this.initializeForm();
    this.loadCountryCodes();
    this.captureUTMParameters();

    this.loadProgramList().then(() => this.restorePreviousData());

    this.landingForm.get('countryCode')?.valueChanges.subscribe((code) => {
      if (code && code !== '+91' && this.selectedMode !== 'international') {
        this.setMode('international');
      } else if (code === '+91' && this.selectedMode !== 'national') {
        this.setMode('national');
      }
    });

    this.routerSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) this.saveFormToStorage();
    });

    window.addEventListener('beforeunload', () => localStorage.removeItem('editFormData'));
  }

  toCaps(controlName: string) {
    const control = this.landingForm.get(controlName);
    if (control && control.value) {
      control.setValue(control.value.toUpperCase(), { emitEvent: false });
    }
  }

  private captureUTMParameters(): void {
    const params = new URLSearchParams(window.location.search);

    this.utmParams = {
      pageUrl: 'https://noida.amity.edu/admission-open/law/',
      utm_source: params.get('utm_source') || '',
      utm_medium: params.get('utm_medium') || '',
      utm_campaign: params.get('utm_campaign') || '',
      utm_content: params.get('utm_content') || '',
      utm_term: params.get('utm_term') || '',
      utm_location: params.get('utm_location') || '',
      State: params.get('State') || '',
      City: params.get('City') || '',
      SourceReferral: params.get('SourceReferral') || '',
      sGCLID: params.get('gclid') || '',
    };
  }

  getLastDate(): void {
    const currentUrl = window.location.href.split('?')[0]; // remove query params

    this.landingService.getLastDateToApply().subscribe({
      next: (res: any) => {
        if (Array.isArray(res) && res.length > 0) {
          // ✅ match PageUrl
          const matched = res.find(
            (item: any) => item.PageUrl?.toLowerCase() === currentUrl.toLowerCase(),
          );

          if (matched) {
            this.lastDateText = matched.LastDate;
          } else {
            this.lastDateText = ''; // no match → hide
          }
        }
      },
      error: (err) => {
        console.error('❌ Error fetching last date', err);
        this.lastDateText = '';
      },
    });
  }

  ngOnDestroy(): void {
    if (this.otpInterval) clearInterval(this.otpInterval);
    if (this.routerSubscription) this.routerSubscription.unsubscribe();
    this.saveFormToStorage();
  }

  private initializeForm(): void {
    this.landingForm = this.fb.group({
      firstName: [
        '',
        [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z ]+$')],
      ],
      email: ['', [Validators.required, Validators.email]],
      countryCode: [{ value: '+91', disabled: true }, Validators.required],
      mobile: ['', [Validators.required, Validators.pattern('^[6-9][0-9]{9}$')]],
      otp: ['', [Validators.pattern('^[0-9]{4,6}$')]],
      ProgramType: ['UG', Validators.required],
      level: [''],
      discipline: [''],
      program: [''],
      specialization: [''],
      Programs: [''],
      courseCode: [''],
      nationalTerms: [true],
      internationalTerms: [false],
    });
  }

  private saveFormToStorage(): void {
    if (!this.landingForm) return;

    const data = this.landingForm.getRawValue();
    const saveData = {
      ...data,
      ...this.utmParams,
      otpVerified: this.otpVerified,
      Mode: this.selectedMode === 'international' ? 'International' : 'National',
      Level: this.selectedLevel,
      Discipline: this.selectedDiscipline,
      Program: this.selectedProgram,
      Programs: data.Programs,
      courseCode: data.courseCode,
      Mobile: `${data.countryCode} ${data.mobile}`,
    };

    localStorage.setItem('editFormData', JSON.stringify(saveData));
  }

  private restorePreviousData(): void {
    const nav = this.router.getCurrentNavigation();
    const formData =
      nav?.extras?.state?.['formData'] ||
      JSON.parse(localStorage.getItem('editFormData') || 'null');

    if (!formData) return;

    this.isEditMode = true;

    const mobileValue =
      formData.Mobile?.replace(/^\+\d+\s*/, '') || formData.mobile || formData.iMobileNo || '';
    const countryCodeValue =
      formData.Mobile?.split(' ')[0] || formData.countryCode || formData.sCountryCode || '+91';
    const courseCodeValue = formData.courseCode || formData.sCourseCd || formData.CourseCode || '';

    this.selectedLevel = formData.Level || '';
    this.selectedDiscipline = 'Law and Legal Studies';
    this.selectedProgram = formData.Program || '';

    // Fixed Discipline
    this.filteredDisciplines = ['Law and Legal Studies'];

    // Programs by Level only
    this.filteredPrograms = [
      ...new Set(
        this.programList
          .filter((p) => p.Level === this.selectedLevel)
          .sort((a, b) => +a.ProgramPopularity - +b.ProgramPopularity)
          .map((p) => p.Program),
      ),
    ];

    // Specializations by Level + Program
    this.filteredSpecializations = [
      ...new Set(
        this.programList
          .filter((p) => p.Level === this.selectedLevel && p.Program === this.selectedProgram)
          .sort((a, b) => +a.CoursePopularity - +b.CoursePopularity)
          .map((p) => p.Programs),
      ),
    ];

    // ✅ Patch values
    this.landingForm.patchValue({
      firstName: formData.Name || formData.firstName || '',
      email: formData.Email || formData.email || '',
      mobile: mobileValue,
      countryCode: countryCodeValue,

      level: this.selectedLevel,
      discipline: 'Law and Legal Studies',
      program: this.selectedProgram,

      specialization: formData.Programs || formData.specialization || '',

      Programs: formData.Programs || '',
      courseCode: courseCodeValue || '',
    });

    // ✅ Fallback for missing courseCode
    if (!this.landingForm.value.courseCode) {
      const found = this.programList.find(
        (p) => p.Level === this.selectedLevel && p.Program === this.selectedProgram,
      );

      if (found) {
        this.landingForm.patchValue({
          courseCode: found.CourseCode,
        });
      }
    }

    if (formData.otpVerified === true || formData.Mode) {
      this.otpVerified = true;
      this.otpStatus = 'success';
      this.otpMessage = '✅ OTP Verified Successfully';
      this.disableOtpFields();
    }

    this.isSubmitbutton = true;
    this.setMode(formData.Mode === 'International' ? 'international' : 'national');

    this.utmParams = {
      utm_source: formData.utm_source,
      utm_medium: formData.utm_medium,
      utm_campaign: formData.utm_campaign,
      utm_content: formData.utm_content,
      utm_term: formData.utm_term,
      utm_location: formData.utm_location,
      State: formData.State,
      City: formData.City,
      SourceReferral: formData.SourceReferral,
    };
  }

  sendGTMEvent(eventName: string, extraData: any = {}) {
    if (typeof window !== 'undefined') {
      window.dataLayer = window.dataLayer || [];

      window.dataLayer.push({
        event: eventName,
        ...this.getFormGTMData(),
        ...extraData,
      });
    }
  }

  private toE164(): string {
    const code = (this.landingForm.get('countryCode')?.value || '').toString().trim();
    const mobileRaw = (this.landingForm.get('mobile')?.value || '').toString().trim();

    if (!mobileRaw) return '';

    const digits = mobileRaw.replace(/\D/g, '');
    if (!digits) return '';

    let cc = code.toString().trim();
    if (!cc.startsWith('+')) {
      cc = `+${cc.replace(/^\+/, '')}`;
    }
    const ccDigits = cc.replace(/\D/g, '');
    return `+${ccDigits}${digits}`;
  }

  private getGtmMobile(): string {
    const code = (this.landingForm.get('countryCode')?.value || '').toString();
    const mobile = (this.landingForm.get('mobile')?.value || '').toString();

    if (!mobile) return '';

    const digits = mobile.replace(/\D/g, '');
    const ccDigits = code.replace(/\D/g, '');

    return ccDigits && digits ? `+${ccDigits}${digits}` : '';
  }

  private pushEcFormSubmit(): void {
    if (typeof window === 'undefined') return;
    (window as any).dataLayer = (window as any).dataLayer || [];

    const raw = this.landingForm.getRawValue();
    const email = (raw.email || '').toString().trim();
    const phoneE164 = this.toE164();

    (window as any).dataLayer.push({
      event: 'ec_form_submit',
      user_data: {
        email: email,
        phone_number: phoneE164,
      },
    });
  }

  private getFormGTMData() {
    const raw = this.landingForm.getRawValue();

    return {
      firstName: raw.firstName || '',
      email: raw.email || '',
      mobile: this.getGtmMobile(),
      level: raw.level || '',
      discipline: raw.discipline || '',
      program: raw.program || '',
      specialization: raw.specialization || '',
      courseCode: raw.courseCode || '',
      mode: this.selectedMode,
      otpVerified: this.otpVerified,
      ...this.utmParams,
    };
  }

  // ✅ +919999999999
  private getMoengageMobile(countryCode: string, mobile: string): string {
    if (!mobile) return '';

    const ccDigits = (countryCode || '').replace(/\D/g, '');
    const mobileDigits = (mobile || '').replace(/\D/g, '');

    return ccDigits && mobileDigits ? `+${ccDigits}${mobileDigits}` : '';
  }

  // ✅ +91-9999999999
  private getMoengageUID(countryCode: string, mobile: string): string {
    if (!mobile) return '';

    const cc = countryCode.startsWith('+') ? countryCode : `+${countryCode.replace(/\D/g, '')}`;

    const mobileDigits = (mobile || '').replace(/\D/g, '');

    return cc && mobileDigits ? `${cc}-${mobileDigits}` : '';
  }

  private resetMoengageSession(): void {
    try {
      if (typeof Moengage !== 'undefined') {
        // 🔴 Logout user (IMPORTANT)
        Moengage.destroy_session?.(); // if available
        Moengage.logout?.(); // fallback

        // 🔴 Remove user attributes (optional but recommended)
        Moengage.remove_unique_user_id?.();
        Moengage.remove_first_name?.();
        Moengage.remove_last_name?.();
        Moengage.remove_email?.();
        Moengage.remove_mobile?.();

        console.log('✅ MoEngage session destroyed');
      }
    } catch (err) {
      console.warn('❌ MoEngage reset failed', err);
    }
  }

  trackMoengage(eventName: string, eventData: any = {}) {
    if (typeof Moengage === 'undefined' || typeof Moengage.track_event !== 'function') {
      return;
    }

    const raw = this.landingForm.getRawValue();

    const firstName = raw.firstName?.toString().trim() || '';
    const email = raw.email?.toString().trim() || '';
    const countryCode = raw.countryCode || '';
    const mobileRaw = raw.mobile || '';

    const mobileAttr = this.getMoengageMobile(countryCode, mobileRaw); // +919999999999
    const uniqueId = this.getMoengageUID(countryCode, mobileRaw); // +91-9999999999

    try {
      if (mobileAttr) {
        Moengage.add_mobile(mobileAttr); // ✅ +919999999999
      }

      if (uniqueId) {
        Moengage.add_unique_user_id(uniqueId); // ✅ +91-9999999999
      }

      if (firstName) Moengage.add_first_name(firstName);
      if (email) Moengage.add_email(email);

      // ✅ ADD FORM NO AS USER ATTRIBUTE
      if (this.formNo) {
        Moengage.add_user_attribute('form_no', this.formNo);
      }

      // optional but useful
      if (this.loginNo) {
        Moengage.add_user_attribute('login_no', this.loginNo);
      }
    } catch (err) {
      console.warn('❌ MoEngage user attribute error', err);
    }

    /* 🔹 EVENT TRACK */
    try {
      Moengage.track_event(eventName, {
        ...eventData,

        // ✅ SEND FORM NO IN EVENTS ALSO
        formNo: this.formNo || '',
        loginNo: this.loginNo || '',

        level: this.selectedLevel,
        discipline: this.selectedDiscipline,
        program: this.selectedProgram,
        specialization: raw.specialization || '',
        mode: this.selectedMode,
        otpVerified: this.otpVerified,
        ...this.utmParams,
      });
    } catch (err) {
      console.warn('❌ MoEngage track_event error', err);
    }
  }

  private disableOtpFields(): void {
    this.landingForm.get('otp')?.disable();
    this.landingForm.get('mobile')?.disable();
    this.landingForm.get('email')?.disable();
    this.landingForm.get('countryCode')?.disable();
    this.isNationalLocked = true;
    this.isInternationalLocked = true;
    this.otpSent = false;
    this.otpTimer = 0;
  }

  setMode(mode: 'national' | 'international'): void {
    this.selectedMode = mode;
    const mobileCtrl = this.landingForm.get('mobile');
    const emailCtrl = this.landingForm.get('email');
    const codeCtrl = this.landingForm.get('countryCode');

    if (mode === 'national') {
      if (codeCtrl?.value !== '+91') codeCtrl?.setValue('+91', { emitEvent: false });
      mobileCtrl?.setValidators([Validators.required, Validators.pattern('^[6-9][0-9]{9}$')]);
    } else {
      if (codeCtrl?.value === '+91') codeCtrl?.setValue('+1', { emitEvent: false });
      mobileCtrl?.setValidators([Validators.required, Validators.pattern('^[0-9]{6,15}$')]);
    }

    emailCtrl?.setValidators([Validators.required, Validators.email]);
    mobileCtrl?.updateValueAndValidity();
    emailCtrl?.updateValueAndValidity();
  }

  get uniqueLevels(): string[] {
    return [...new Set(this.programList.map((p) => p.Level))];
  }

  private loadCountryCodes(): void {
    this.landingService.getCountryCodes().subscribe({
      next: (res) => {
        if (res.success && Array.isArray(res.data)) {
          this.countryCodes = res.data.map((c) => c.CountryCode);
        }
      },
      error: (err) => console.error('Error loading country codes:'),
    });
  }

  loadProgramList(): Promise<void> {
    return new Promise((resolve) => {
      this.landingService.getProgramList().subscribe({
        next: (response) => {
          if (response.success && response.data) {
            // Only Law and Legal Studies data
            this.programList = response.data.filter(
              (p) =>
                p.Discipline?.trim().toLowerCase() === 'law and legal studies' ||
                p.Discipline1?.trim().toLowerCase() === 'law and legal studies',
            );

            this.selectedDiscipline = 'Law and Legal Studies';

            this.filteredDisciplines = ['Law and Legal Studies'];

            this.landingForm.patchValue({
              discipline: 'Law and Legal Studies',
            });

            this.cdr.detectChanges();
          }

          resolve();
        },
        error: () => resolve(),
      });
    });
  }

  handleOtp(target: 'mobile' | 'email'): void {
    const rawForm = this.landingForm.getRawValue(); // <- includes disabled fields

    this.sendGTMEvent('generate_otp_clicked', {
      type: target,
      mobile: this.getGtmMobile(),
    });

    this.trackMoengage('otp_generate_clicked', {
      target,
      FirstName: rawForm.firstName,
      Email: rawForm.email,
    });

    if (this.otpTimer > 0) return;

    const code = rawForm.countryCode;
    const mobile = rawForm.mobile;
    const email = rawForm.email;

    this.isSubmitting = true;
    this.otpVerified = false;
    this.otpMessage = '';
    this.otpStatus = '';

    if (target === 'mobile') {
      if (code !== '+91') {
        this.isSubmitting = false;
        this.otpStatus = 'error';
        this.otpMessage = 'OTP can only be sent to Indian (+91) numbers.';
        return;
      }
      if (!mobile || !/^[6-9][0-9]{9}$/.test(mobile)) {
        this.isSubmitting = false;
        this.otpStatus = 'error';
        this.otpMessage = 'Please enter a valid mobile number.';
        return;
      }
    } else if (target === 'email') {
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        this.isSubmitting = false;
        this.otpStatus = 'error';
        this.otpMessage = 'Please enter a valid email address.';
        return;
      }
    }

    this.landingService.sendOtp({ ...rawForm, ...this.utmParams, target }).subscribe({
      next: (res: OtpResponse) => {
        this.isSubmitting = false;

        if (res.success) {
          this.loginNo = res.loginNo || '';
          this.otpSent = true;
          this.startOtpTimer();
          this.otpStatus = 'success';
          this.otpMessage =
            target === 'email' ? 'OTP sent to your Email.' : 'OTP sent to your Mobile.';

          // Keep fields disabled after sending OTP
          (target === 'mobile'
            ? this.landingForm.get('mobile')
            : this.landingForm.get('email')
          )?.disable();
        } else {
          this.otpStatus = 'error';
          this.otpMessage = res.message || 'Failed to send OTP.';
        }
      },
      error: () => {
        this.isSubmitting = false;
        this.otpStatus = 'error';
        this.otpMessage = 'Error sending OTP.';
      },
    });
  }

  resendOtp(target: 'mobile' | 'email' = 'mobile'): void {
    if (this.otpTimer > 0) {
      Swal.fire({
        text: `Please wait ${this.otpTimer}s before re-sending OTP.`,
        icon: 'info',
        confirmButtonColor: '#4d306a',
      });
      return;
    }

    this.landingForm.get('otp')?.reset();
    this.otpVerified = false;
    this.otpMessage = '';
    this.otpStatus = '';

    // Call OTP handler
    this.handleOtp(target);
  }

  startOtpTimer(): void {
    this.otpTimer = 30;
    clearInterval(this.otpInterval);
    this.otpInterval = setInterval(() => {
      this.otpTimer--;
      if (this.otpTimer <= 0) {
        clearInterval(this.otpInterval);
        this.otpInterval = null;
      }
    }, 1000);
  }

  onOtpInput() {
    const otp = this.landingForm.get('otp')?.value;

    if (!otp) return;

    const cleanOtp = otp.toString().trim();

    // ✅ Only trigger when exactly 4 digits
    if (!/^\d{4}$/.test(cleanOtp)) return;

    // ✅ Prevent multiple API calls
    if (this.otpVerified || this.isSubmitting) return;

    // ✅ Call your existing full logic
    this.verifyOtp();
  }

  verifyOtp(): void {
    // ✅ Prevent multiple API calls
    if (this.isSubmitting || this.otpVerified) return;

    const otp = this.landingForm.value.otp?.toString().trim();

    // ✅ Validate 4-digit OTP
    if (!otp || !/^\d{4}$/.test(otp)) {
      this.otpStatus = 'error';
      this.otpMessage = 'Please enter valid 4-digit OTP.';
      return;
    }

    // ✅ Check loginNo
    if (!this.loginNo) {
      this.otpStatus = 'error';
      this.otpMessage = 'LoginNo missing. Send OTP again.';
      return;
    }

    // 🔥 INSTANT UI FEEDBACK (important for speed feel)
    this.otpStatus = '';
    this.otpMessage = 'Verifying OTP...';
    this.isSubmitting = true;

    // 🔒 Disable OTP input while verifying
    this.landingForm.get('otp')?.disable();

    // ✅ Tracking (non-blocking, after validation)
    this.sendGTMEvent('otp_verify_click', {});
    this.trackMoengage('otp_verified', {
      FirstName: this.landingForm.value.firstName,
      Email: this.landingForm.value.email,
      formNo: this.formNo,
      loginNo: this.loginNo,
    });

    this.landingService.verifyOtp(this.loginNo, otp).subscribe({
      next: (res: any) => {
        this.isSubmitting = false;

        if (res.success) {
          this.sendGTMEvent('otp_verified', {
            loginNo: this.loginNo,
            mobile: this.landingForm.value.mobile,
          });

          this.otpVerified = true;
          this.otpStatus = 'success';
          this.otpMessage = '✅ OTP Verified Successfully';
          this.formNo = res.form?.[0]?.FormNo?.toString() || '';

          this.disableOtpFields(); // already disables everything

          const paid = res.form?.[0]?.Paid === true;

          if ((paid && res.caseType == '1') || res.caseType == '2') {
            const studentName = this.landingForm.get('firstName')?.value || '';

            const message = `<div style="font-size: 14px; text-align: start; line-height: 22px">
              Dear <b>${studentName}</b>,
              <br />
              You are already <b>registered</b> with Amity University Noida, welcome back! <br />
              Continue your journey by signing in to the Admission Portal to complete your application or explore your dashboard.
            </div>`;

            Swal.fire({
              html: message,
              confirmButtonText: 'Proceed to admission portal',
              confirmButtonColor: '#0b2d4c',
              allowOutsideClick: false,
            }).then(({ isConfirmed }) => {
              if (!isConfirmed) return;

              this.landingService.verifyCompletedFormToken(res.token).subscribe({
                next: () => {
                  window.location.href = `https://portal.amity.edu/NewOnlineForm/OnlineForms/DirectWebLogin?token=${res.token}`;
                },
                error: () => {
                  Swal.fire({
                    text: 'Token verification failed. Please try again later.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                  });
                },
              });
            });
          }

          sessionStorage.setItem('token', res.token);

          setTimeout(() => {
            this.otpMessage = '';
            this.otpStatus = '';
          }, 4000);
        } else {
          // ❌ Failure case
          this.otpStatus = 'error';
          this.otpMessage = res.message || 'OTP verification failed.';

          // 🔓 Re-enable OTP input
          this.landingForm.get('otp')?.enable();
        }
      },

      error: () => {
        this.isSubmitting = false;
        this.otpStatus = 'error';
        this.otpMessage = 'OTP verification error.';

        // 🔓 Re-enable OTP input
        this.landingForm.get('otp')?.enable();
      },
    });
  }

  onLevelChange(event: Event): void {
    this.selectedLevel = (event.target as HTMLSelectElement).value;

    this.selectedDiscipline = 'Law and Legal Studies';

    this.filteredPrograms = [
      ...new Set(
        this.programList
          .filter((p) => p.Level === this.selectedLevel)
          .sort((a, b) => +a.ProgramPopularity - +b.ProgramPopularity)
          .map((p) => p.Program),
      ),
    ];

    this.filteredSpecializations = [];

    this.selectedProgram = '';

    this.landingForm.patchValue({
      discipline: 'Law and Legal Studies',
      program: '',
      specialization: '',
      courseCode: '',
    });
  }
  onDisciplineChange(event: Event): void {
    const discipline = (event.target as HTMLSelectElement).value;

    this.selectedDiscipline = discipline;

    // Get all records for selected discipline
    const filteredData = this.programList.filter(
      (p) =>
        (p.Discipline && p.Discipline.trim().toLowerCase() === discipline.trim().toLowerCase()) ||
        (p.Discipline1 && p.Discipline1.trim().toLowerCase() === discipline.trim().toLowerCase()),
    );

    // Auto select level
    if (filteredData.length > 0) {
      this.selectedLevel = filteredData[0].Level;

      this.landingForm.patchValue({
        level: this.selectedLevel,
      });
    }

    // Load programs
    this.filteredPrograms = [
      ...new Set(
        filteredData
          .sort((a, b) => +a.ProgramPopularity - +b.ProgramPopularity)
          .map((p) => p.Program),
      ),
    ];

    this.filteredSpecializations = [];

    this.landingForm.patchValue({
      program: '',
      specialization: '',
      courseCode: '',
    });

    this.isSubmitbutton = false;
  }

  onProgramChange(event: Event): void {
    this.selectedProgram = (event.target as HTMLSelectElement).value;

    this.filteredSpecializations = [
      ...new Set(
        this.programList
          .filter((p) => p.Level === this.selectedLevel && p.Program === this.selectedProgram)
          .sort((a, b) => +a.CoursePopularity - +b.CoursePopularity)
          .map((p) => p.Programs),
      ),
    ];

    this.landingForm.patchValue({
      specialization: '',
      courseCode: '',
    });
  }

  onSpecializationChange(event: Event): void {
    const specialization = (event.target as HTMLSelectElement).value;

    const selected = this.programList.find(
      (p) =>
        p.Level === this.selectedLevel &&
        p.Program === this.selectedProgram &&
        p.Programs === specialization,
    );

    if (selected) {
      this.landingForm.patchValue({
        specialization,
        Programs: specialization,
        courseCode: selected.CourseCode,
      });

      this.isSubmitbutton = true;
    } else {
      this.landingForm.patchValue({
        courseCode: '',
      });

      this.isSubmitbutton = false;
    }
  }

  private resetFormFilters(fields: string[]): void {
    const patch: any = {};
    fields.forEach((f) => (patch[f] = ''));
    this.landingForm.patchValue(patch);
  }

  submitFinalForm(): void {
    debugger;
    this.sendGTMEvent('lead_form_submitted', {
      firstName: this.landingForm.value.firstName,
      email: this.landingForm.value.email,
      level: this.selectedLevel,
      discipline: this.selectedDiscipline,
      program: this.selectedProgram,
      specialization: this.landingForm.value.specialization,
    });

    this.trackMoengage('lead_form_submitted', {
      firstName: this.landingForm.value.firstName,
      email: this.landingForm.value.email,
      level: this.selectedLevel,
      discipline: this.selectedDiscipline,
      program: this.selectedProgram,
      specialization: this.landingForm.value.specialization,
      formNo: this.formNo,
      loginNo: this.loginNo,
    });

    // this.trackMoengage('lead_form_submitted', {
    //   firstName: this.landingForm.value.firstName,
    //   email: this.landingForm.value.email,
    //   level: this.selectedLevel,
    //   discipline: this.selectedDiscipline,
    //   program: this.selectedProgram,
    //   specialization: this.landingForm.value.specialization,
    // });

    if (!this.otpVerified) {
      alert('Please verify OTP before submitting.');
      return;
    }

    if (this.landingForm.invalid) {
      this.landingForm.markAllAsTouched();
      alert('Please fill all required fields.');
      return;
    }

    const data = this.landingForm.getRawValue();

    if (!data.mobile || !data.courseCode) {
      alert('Missing required fields: Mobile and Course Code are required.');
      return;
    }

    const termsAccepted =
      (this.selectedMode === 'national' && data.nationalTerms) ||
      (this.selectedMode === 'international' && data.internationalTerms);

    if (!termsAccepted) {
      alert('Please accept the declaration.');
      return;
    }

    this.pushEcFormSubmit();

    this.isSubmitting = true;
    localStorage.removeItem('editFormData');

    this.previewData = {
      
      firstName: data.firstName,
      Email: data.email,
      Mobile: `${data.countryCode} ${data.mobile}`,
      Mode: this.selectedMode === 'international' ? 'International' : 'National',
      Level: this.selectedLevel,
      Discipline: this.selectedDiscipline,
      Program: this.selectedProgram,
      Programs: data.Programs,
    };

    const payload = {
      firstName: data.firstName,
      email: data.email,
      countryCode: data.countryCode,
      mobile: data.mobile,
      courseCode: data.courseCode,
      formNo: this.formNo,
      loginNo: this.loginNo,
      INTNL: this.selectedMode === 'international',
      utm_source: this.utmParams.utm_source,
      utm_medium: this.utmParams.utm_medium,
      utm_campaign: this.utmParams.utm_campaign,
      utm_content: this.utmParams.utm_content,
      utm_term: this.utmParams.utm_term,
      utm_location: this.utmParams.utm_location,
      State: this.utmParams.State,
      City: this.utmParams.City,
      SourceReferral: this.utmParams.SourceReferral,
    };

    this.landingService.submitFinalForm(payload).subscribe({
      next: (res) => {
        this.isSubmitting = false;
        if (res.success) {
          this.resetMoengageSession();

          const uid = res.userGenNo || res.form?.[0]?.userGenNo || '';
          const paid = res.form?.[0]?.paid || false;
          sessionStorage.setItem('allowPreview', 'true');

          if (this.selectedMode === 'international') {
            this.router.navigate(['/preview'], {
              state: {
                UID: uid,
                previewData: this.previewData,
                isInternational: true,
              },
            });
          } else {
            this.router.navigate(['/preview'], {
              state: {
                UID: uid,
                previewData: this.previewData,
                isInternational: false,
              },
            });
          }
        } else {
          alert(res.message || 'Submission failed.');
        }
      },
      error: (err) => {
        this.isSubmitting = false;
        alert('Form submission failed. Please try again.');
      },
    });
  }
}
