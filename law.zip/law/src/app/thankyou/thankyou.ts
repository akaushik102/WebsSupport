import {
  Component,
  OnInit,
  AfterViewInit,
  ElementRef,
  ViewChild,
  Renderer2,
} from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  LandingserviceService,
  TransactionData,
  TransactionStatusResponse,
} from '../service/landingservice.service';

declare var $: any;
declare const Moengage: any;

@Component({
  selector: 'app-thankyou',
  imports: [CommonModule],
  templateUrl: './thankyou.html',
  styleUrl: './thankyou.css',
})
export class Thankyou implements OnInit, AfterViewInit {
  status: 'success' | 'failure' = 'failure';
  uid = '';
  //paymentDetails: TransactionStatusResponse['data'] | null = null;
  paymentDetails: TransactionData | null = null;
  details: any = { INTNL: false };
  activeIndex: number | null = 0;

  private scrollAnimationFrame?: number;

  @ViewChild('placementSlider', { static: false })
  placementSlider!: ElementRef<HTMLDivElement>;
  sessionToken: string = '';

  constructor(
    private route: ActivatedRoute,
    private api: LandingserviceService,
    private renderer: Renderer2,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(async (params) => {
      this.uid = params['UID'] || '';
      const urlStatus = params['status'];

      if (urlStatus) {
        this.status = urlStatus === 'success' ? 'success' : 'failure';

        if (this.uid) {
          await this.fetchTransactionStatus(this.uid);
        }

        this.fireThankYouEvents();
      } else if (this.uid) {
        await this.fetchTransactionStatus(this.uid);
        this.fireThankYouEvents();
      }
    });
  }

  // ngOnInit(): void {
  //   this.route.queryParams.subscribe((params) => {
  //     this.uid = params['UID'] || '';
  //     const urlStatus = params['status'];

  //     if (urlStatus) {
  //       this.status = urlStatus === 'success' ? 'success' : 'failure';
  //       setTimeout(() => {
  //         this.fireThankYouEvents();
  //       }, 300);
  //     } else if (this.uid) {
  //       this.fetchTransactionStatus(this.uid);
  //     }
  //   });
  // }

  private fireThankYouEvents(): void {
    this.sendGTMEvent('thank_you_page_viewed_' + this.status, {
      UID: this.uid,
      status: this.status,

      campusName: this.details?.campusName || '',
      courseCode: this.details?.courseCode || '',
      courseName: this.details?.courseName || '',
      formNo: this.details?.formNo || '',
      pageURL: window.location.href,

      paymentStatus: this.details?.paymentStatus || '',
      pgResponse: this.details?.pgResponse || '',
      pgResponseCode: this.details?.pgResponseCode || '',

      studentCampus: this.details?.studentCampus || '',
      studentCountry: this.details?.studentCountry || '',
      studentCourse: this.details?.studentCourse || '',
      studentDiscipline: this.details?.studentDiscipline || '',
      studentEmail: this.details?.studentEmail || '',
      studentLevel: this.details?.studentLevel || '',
      studentMobile: this.details?.studentMobile || '',
      studentName: this.details?.studentName || '',
      studentProgram: this.details?.studentProgram || '',

      isInternational: this.details?.INTNL ?? false,
    });

    this.trackMoengage(
      this.status === 'success' ? 'payment_success' : 'payment_failed',
      {
        UID: this.uid,
        isInternational: this.details?.INTNL ?? false,
      },
    );
  }

  sendGTMEvent(eventName: string, eventData: any = {}) {
    if (typeof window === 'undefined') return;

    (window as any).dataLayer = (window as any).dataLayer || [];

    console.log('📊 GTM EVENT:', eventName, eventData);

    (window as any).dataLayer.push({
      event: eventName,
      ...eventData,
    });
  }

  trackMoengage(eventName: string, eventData: any = {}) {
    if (typeof Moengage === 'undefined') return;

    try {
      Moengage.track_event(eventName, {
        uid: this.uid,
        status: this.status,
        isInternational: this.details?.INTNL ?? false,
        ...eventData,
      });
    } catch (err) {
      console.warn('❌ MoEngage tracking failed', err);
    }
  }

  async fetchTransactionStatus(uid: string) {
    return new Promise((resolve, reject) => {
      this.api.getTransactionStatus(uid).subscribe({
        next: (res) => {
          if (res.success) {
            this.paymentDetails = res.data;
            this.status = res.approved === true ? 'success' : 'failure';
            this.details = {
              ...res.data,
              INTNL: false,
            };

            this.sessionToken = res.token;
            resolve(this.status);
          } else {
            this.status = 'failure';
            reject();
          }
        },

        error: (err) => {
          this.paymentDetails = null;
          this.status = 'failure';
        },
      });
    });
  }

  ngAfterViewInit(): void {
    const script = this.renderer.createElement('script');
    script.src = 'https://videosuite-player-wrapper.vercel.app/assets';
    script.async = true;
    this.renderer.appendChild(document.body, script);

    setTimeout(() => this.initOwlCarousel(), 300);
    setTimeout(() => this.startPlacementLogoScroll(), 800);
  }

  initOwlCarousel(): void {
    if ($('.owl-carousel').length) {
      $('.owl-carousel').owlCarousel({
        items: 1,
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        nav: true,
        dots: true,
        navText: [
          '<i class="fas fa-chevron-left"></i>',
          '<i class="fas fa-chevron-right"></i>',
        ],
      });
    }
  }

  faqs = [
    {
      question:
        'Where can I access the list of all programs offered at Amity University, Noida?',
      answer: `<p>The list of all programs offered at Amity Noida can be accessed by <a href="https://amity.edu/noida/programmesnew.aspx?fd=all" target="_blank"><strong>clicking here.</strong></a></p>`,
    },
    {
      question:
        'What is the minimum eligibility to avail the scholarship opportunities at Amity University?',
      answer: `<p>The scholarship eligibility and amount vary based on the program, type of scholarship, and students’ previous academic performance. For details, go through our <a href="https://amity.edu/noida/scholarships.aspx" target="_blank"><strong>scholarship information page.</strong></a></p>`,
    },
    {
      question:
        'Can I get an education loan to pursue my studies at Amity University?',
      answer:
        `<p>Yes! For the benefit of prospective students at Amity, we have tied up with all leading banks across the country. These banks give educational loans to cover tuition fees, books cost, hostel fees, airfare for courses abroad, etc.</p>`,
    },
    {
      question:
        'How is the campus and student life like at Amity University, Noida?',
      answer:
        `<p>Life at Amity goes beyond the classroom. With a lush green campus spanning over 85 acres comprising modern classrooms, hi-tech labs and libraries, expansive sports complexes, multi-cuisine restaurants, bookstores, and on-campus hostels, there is never a dull moment at Amity’s campus. Students have a wide range of leisure, sports, and cultural activities to get involved in.</p>`,
    },
    {
      question:
        'Can a student apply for a UG/PG program in absence of 10+2 or final year result of graduation?',
      answer:
        `<p>Yes, a student may apply provisionally for any program but needs to produce all the original Mark sheets/ Degrees at the time of Joining the Program. However, for the applicant of PG Program, 31st October (of the current academic year) is the last date to submit the original Mark sheets / Degrees.</p>
                                        <p>Your verification will remain incomplete in case you fail to submit the required documents. In the absence of verification, you will not be able to appear for the end semester examination.</p>`,
    },
  ];

  toggleAccordion(index: number): void {
    this.activeIndex = this.activeIndex === index ? null : index;
  }

  logos = Array.from(
    { length: 17 },
    (_, i) => `images/placements-logo${i + 1}.jpg`,
  );

  startPlacementLogoScroll(): void {
    const slider = this.placementSlider?.nativeElement;
    if (!slider) return;

    const clone = slider.innerHTML;
    slider.insertAdjacentHTML('beforeend', clone);

    let scrollLeft = 0;
    const speed = 0.8;

    const scroll = () => {
      scrollLeft += speed;
      if (scrollLeft >= slider.scrollWidth / 2) scrollLeft = 0;
      slider.scrollLeft = scrollLeft;
      this.scrollAnimationFrame = requestAnimationFrame(scroll);
    };

    this.scrollAnimationFrame = requestAnimationFrame(scroll);

    slider.addEventListener('mouseenter', () =>
      cancelAnimationFrame(this.scrollAnimationFrame!),
    );
    slider.addEventListener(
      'mouseleave',
      () => (this.scrollAnimationFrame = requestAnimationFrame(scroll)),
    );
  }
}
