import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const formAccessGuard: CanActivateFn = (route) => {
  const router = inject(Router);

  const allowPreview = sessionStorage.getItem('allowPreview');
  // const allowThankyou = sessionStorage.getItem('allowThankyou');

  // 👇 check route
  if (route.routeConfig?.path === 'preview') {
    if (allowPreview) return true;
  }

  // if (route.routeConfig?.path === 'thankyou') {
  //   if (allowThankyou) return true;
  // }

  // ❌ block
  router.navigate(['/']);
  return false;
};