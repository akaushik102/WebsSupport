import { Component } from '@angular/core';
import { Mainform } from "../mainform/mainform";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [Mainform, CommonModule],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  activeIndex: number | null = 0;

  faqs = [
    {
      question:
        'Where can I access the list of all programs offered at Amity University, Noida?',
      answer: `<p>The list of all programs offered at Amity Noida can be accessed by <a href="https://amity.edu/noida/programmesnew.aspx?fd=all" target="_blank"><strong>clicking here.</strong></a></p>`,
    },
    {
      question:
        'What is the minimum eligibility to avail the scholarship opportunities at Amity University?',
      answer: `<p>The scholarship eligibility and amount vary based on the program, type of scholarship, and students’ previous academic performance. For details, go through our <a href="https://amity.edu/noida/scholarships.aspx" target="_blank"><strong>scholarship information page.</strong></a></p>`,
    },
    {
      question:
        'Can I get an education loan to pursue my studies at Amity University?',
      answer:
        `<p>Yes! For the benefit of prospective students at Amity, we have tied up with all leading banks across the country. These banks give educational loans to cover tuition fees, books cost, hostel fees, airfare for courses abroad, etc.</p>`,
    },
    {
      question:
        'How is the campus and student life like at Amity University, Noida?',
      answer:
        `<p>Life at Amity goes beyond the classroom. With a lush green campus spanning over 85 acres comprising modern classrooms, hi-tech labs and libraries, expansive sports complexes, multi-cuisine restaurants, bookstores, and on-campus hostels, there is never a dull moment at Amity’s campus. Students have a wide range of leisure, sports, and cultural activities to get involved in.</p>`,
    },
    {
      question:
        'Can a student apply for a UG/PG program in absence of 10+2 or final year result of graduation?',
      answer:
        `<p>Yes, a student may apply provisionally for any program but needs to produce all the original Mark sheets/ Degrees at the time of Joining the Program. However, for the applicant of PG Program, 31st October (of the current academic year) is the last date to submit the original Mark sheets / Degrees.</p>
                                        <p>Your verification will remain incomplete in case you fail to submit the required documents. In the absence of verification, you will not be able to appear for the end semester examination.</p>`,
    },
  ];

  toggleAccordion(index: number): void {
    this.activeIndex = this.activeIndex === index ? null : index;
  }


}
