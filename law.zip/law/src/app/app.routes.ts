import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Paynow } from './paynow/paynow';
import { Thankyou } from './thankyou/thankyou';
import { formAccessGuard } from './guards/form-access.guard';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'preview', component: Paynow, canActivate: [formAccessGuard] },
  { path: 'thankyou', component: Thankyou},
];
