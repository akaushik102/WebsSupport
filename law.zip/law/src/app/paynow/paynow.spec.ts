import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Paynow } from './paynow';

describe('Paynow', () => {
  let component: Paynow;
  let fixture: ComponentFixture<Paynow>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Paynow],
    }).compileComponents();

    fixture = TestBed.createComponent(Paynow);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
