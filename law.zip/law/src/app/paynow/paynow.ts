import { Component, OnInit, AfterViewInit, OnDestroy, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router} from '@angular/router';
import { LandingserviceService } from '../service/landingservice.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import Swal from 'sweetalert2';

declare var $: any;

@Component({
  selector: 'app-paynow',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './paynow.html',
  styleUrl: './paynow.css',
})
export class Paynow implements OnInit{
  uid: string = '';
  previewData: any = null;
  showPreview = false;
  agreeChecked: boolean = true;
  isInternational = false;

  activeIndex: number | null = 0;

  constructor(private router: Router, private landingService: LandingserviceService) {}

  editForm(): void {
    this.sendGTMEvent('edit_form_clicked', {
      uid: this.uid,
    });

    this.trackMoengage('edit_form_clicked', { uid: this.uid });

    if (this.previewData) {
      localStorage.setItem('editFormData', JSON.stringify(this.previewData));
      this.router.navigate(['/'], { state: { formData: this.previewData } });
    }
  }

  ngOnInit(): void {
    const allowPreview = sessionStorage.getItem('allowPreview');
    const navState = history.state;

    // ❌ Direct access block
    if (!allowPreview || !navState?.previewData) {
      this.router.navigate(['/']);
      return;
    }

    this.sendGTMEvent('paynow_page_loaded', {
      uid: this.uid || null,
      isInternational: this.isInternational,
    });

    this.trackMoengage('paynow_page_loaded', { uid: this.uid, isInternational: this.isInternational });

    this.isInternational = navState?.isInternational || false;

    if (navState?.UID) this.uid = navState.UID;

    if (!this.uid && navState?.previewData?.UID) this.uid = navState.previewData.UID;

    if (!this.uid) {
      const storedUID = localStorage.getItem('UID');
      if (storedUID) this.uid = storedUID;
    }

    if (this.uid) localStorage.setItem('UID', this.uid);

    if (navState?.previewData) {
      this.previewData = navState.previewData;
      localStorage.setItem('previewData', JSON.stringify(this.previewData));
    } else {
      const saved = localStorage.getItem('previewData');
      if (saved) this.previewData = JSON.parse(saved);
    }

    if (this.previewData) this.showPreview = true;
  }

  sendGTMEvent(eventName: string, eventData: any = {}) {
    if (typeof window !== 'undefined') {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: eventName,
        ...eventData,
      });
    }
  }

  trackMoengage(eventName: string, eventData: any = {}) {
    if (typeof Moengage === 'undefined' || typeof Moengage.track_event !== 'function') {
      console.warn('Moengage is not initialized');
      return;
    }

    const firstName = this.previewData?.firstName?.toString().trim() || '';
    const email = this.previewData?.email?.toString().trim() || '';
    const mobileRaw = this.previewData?.mobile?.toString().trim() || '';
    const countryCode = this.previewData?.countryCode?.toString().trim() || '';
    

    const mobileAttr = countryCode && mobileRaw ? `${countryCode}-${mobileRaw}` : mobileRaw;

    try {
      if (mobileAttr) {
        Moengage.add_unique_user_id(mobileAttr);
        Moengage.add_mobile(mobileAttr);
      }

      if (firstName) Moengage.add_first_name(firstName);
      if (email) Moengage.add_email(email);
    } catch (err) {
      console.warn('Moengage attribute set failed', err);
    }

    try {
      Moengage.track_event(eventName, eventData);
    } catch (err) {
      console.warn('Moengage track_event failed', err);
    }
  }

  payNow(): void {
    this.sendGTMEvent('application_fee_initiated', {
      uid: this.uid,
      isInternational: this.isInternational,
    });

    this.trackMoengage('application_fee_initiated', { uid: this.uid, isInternational: this.isInternational });

    if (!this.agreeChecked) {
      Swal.fire('Please agree to the declaration before proceeding.', '', 'warning');
      return;
    }

    if (!this.uid) {
      Swal.fire('UID missing. Cannot initiate payment.', '', 'error');
      return;
    }

    if (this.isInternational) {
      const token = sessionStorage.getItem('token');
      const paymentUrl = `https://portal.amity.edu/NewOnlineForm/OnlineForms/DirectWebLogin?token=${token}`;
      Swal.fire({
        // title: 'Redirecting...',
        text: 'Click OK to continue',
        icon: 'info',
        confirmButtonText: 'OK',
        confirmButtonColor: '#f0ad4e',
      }).then((res) => {
        if (res.isConfirmed) window.open(paymentUrl, '_blank');
      });
      return;
    }

    this.landingService.processPayment(this.uid).subscribe({
      next: (res: any) => {
        if (res.status === 'approved' || res.status === 'success') {
          this.router.navigate(['/thankyou'], {
            queryParams: { status: 'success' },
            state: { UID: this.uid },
          });
        } else if (res.status === 'new_payment_initiated' && res.parameters && res.paytmUrl) {
          const form = document.createElement('form');
          form.method = 'POST';
          form.action = res.paytmUrl;

          Object.keys(res.parameters).forEach((key) => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = res.parameters[key];
            form.appendChild(input);
          });

          document.body.appendChild(form);
          form.submit();
        } else {
          this.router.navigate(['/thankyou'], {
            queryParams: { status: 'failure' },
            state: { UID: this.uid },
          });
        }
      },
      error: () => {
        this.router.navigate(['/thankyou'], {
          queryParams: { status: 'failure' },
          state: { UID: this.uid },
        });
      },
    });
  }

  faqs = [
    {
      question:
        'Where can I access the list of all programs offered at Amity University, Noida?',
      answer: `<p>The list of all programs offered at Amity Noida can be accessed by <a href="https://amity.edu/noida/programmesnew.aspx?fd=all" target="_blank"><strong>clicking here.</strong></a></p>`,
    },
    {
      question:
        'What is the minimum eligibility to avail the scholarship opportunities at Amity University?',
      answer: `<p>The scholarship eligibility and amount vary based on the program, type of scholarship, and students’ previous academic performance. For details, go through our <a href="https://amity.edu/noida/scholarships.aspx" target="_blank"><strong>scholarship information page.</strong></a></p>`,
    },
    {
      question:
        'Can I get an education loan to pursue my studies at Amity University?',
      answer:
        `<p>Yes! For the benefit of prospective students at Amity, we have tied up with all leading banks across the country. These banks give educational loans to cover tuition fees, books cost, hostel fees, airfare for courses abroad, etc.</p>`,
    },
    {
      question:
        'How is the campus and student life like at Amity University, Noida?',
      answer:
        `<p>Life at Amity goes beyond the classroom. With a lush green campus spanning over 85 acres comprising modern classrooms, hi-tech labs and libraries, expansive sports complexes, multi-cuisine restaurants, bookstores, and on-campus hostels, there is never a dull moment at Amity’s campus. Students have a wide range of leisure, sports, and cultural activities to get involved in.</p>`,
    },
    {
      question:
        'Can a student apply for a UG/PG program in absence of 10+2 or final year result of graduation?',
      answer:
        `<p>Yes, a student may apply provisionally for any program but needs to produce all the original Mark sheets/ Degrees at the time of Joining the Program. However, for the applicant of PG Program, 31st October (of the current academic year) is the last date to submit the original Mark sheets / Degrees.</p>
                                        <p>Your verification will remain incomplete in case you fail to submit the required documents. In the absence of verification, you will not be able to appear for the end semester examination.</p>`,
    },
  ];

  toggleAccordion(index: number): void {
    this.activeIndex = this.activeIndex === index ? null : index;
  }


}