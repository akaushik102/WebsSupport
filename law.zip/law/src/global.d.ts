// declare global {
//   interface Window {
//     dataLayer: any[];
//   }
// }


// declare var Moengage: {
//   track_event: (eventName: string, data?: any) => void;
// };

// export {};


declare global {
  interface Window {
    dataLayer?: any[];
    Moengage?: {
      track_event: (eventName: string, data?: any) => void;
    };
  }
}

declare var Moengage: {
  track_event: (eventName: string, data?: any) => void;
} | undefined;

export {};

